<?php

use nitropackio\compatibility\controller\Admin as Controller;

class ControllerExtensionModuleNitropack extends Controller {}
