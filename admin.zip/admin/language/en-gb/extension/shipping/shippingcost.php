<?php
// Heading
$_['heading_title']    = 'Seller Shipping Cost';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Success: You have modified Shipping Cost shipping!';
$_['text_edit']        = 'Edit Shipping Cost';
$_['text_extension']   = 'Extension';

// Entry
$_['entry_status']      = 'Status';
$_['entry_sort_order']  = 'Sort Order';
$_['entry_tax_class']   = 'Tax Class';
$_['entry_title']       = 'Title';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Shipping Cost!';