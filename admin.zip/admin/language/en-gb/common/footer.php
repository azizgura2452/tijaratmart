<?php
// Text
$_['text_footer']  = 'Developed by: <a href="mailto:azizgura@gmail.com">Aziz Gura</a> &copy; ' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Version %s';